from flask import Flask, redirect, render_template, request, url_for
from SearchFiles import Page_search

app = Flask(__name__)

@app.route("/")
@app.route('/index')
def index():
    return render_template("index.html")


@app.route('/results', methods=['GET'])
def results():
    search_content = request.args.get('search_content')
    Matching_num, Searching_result,comments = Page_search(search_content)
    return render_template("results.html", search_content = search_content, Matching_num = Matching_num, Searching_result = Searching_result,comments = comments)


if __name__ == '__main__':
    app.run(debug=True, port=4578)
